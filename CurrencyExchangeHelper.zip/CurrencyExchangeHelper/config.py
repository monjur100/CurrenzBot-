import os

# Telegram Bot API Token
BOT_TOKEN = os.getenv("BOT_TOKEN", "7897563363:AAHSfwWaig4PLYmfXHT3B-8mDMxTM2Q3Umg")

# Exchange Rate API Key (not needed for the free tier of this API)
EXCHANGE_RATE_API_KEY = ""

# Exchange Rate API Base URL
EXCHANGE_RATE_API_URL = "https://open.er-api.com/v6/latest/"

# Call to action button details
CTA_TEXT = "Convert currency with best rate"
CTA_URL = "https://wise.com/invite/dic/mdmonjuruli1"

# Popular currency codes and their emoji representations
CURRENCY_EMOJIS = {
    "USD": "🇺🇸",
    "EUR": "🇪🇺",
    "GBP": "🇬🇧",
    "JPY": "🇯🇵",
    "AUD": "🇦🇺",
    "CAD": "🇨🇦",
    "CHF": "🇨🇭",
    "CNY": "🇨🇳",
    "HKD": "🇭🇰",
    "NZD": "🇳🇿",
    "INR": "🇮🇳",
    "MXN": "🇲🇽",
    "SGD": "🇸🇬",
    "RUB": "🇷🇺",
    "ZAR": "🇿🇦",
    "BRL": "🇧🇷",
    "TRY": "🇹🇷",
    "IDR": "🇮🇩",
    "MYR": "🇲🇾",
    "PHP": "🇵🇭",
    "THB": "🇹🇭",
    "KRW": "🇰🇷",
    "BGN": "🇧🇬",
    "PLN": "🇵🇱",
    "SEK": "🇸🇪",
    "NOK": "🇳🇴",
    "DKK": "🇩🇰",
    "CZK": "🇨🇿",
    "HUF": "🇭🇺",
    "RON": "🇷🇴"
}

# Default base currency
DEFAULT_BASE_CURRENCY = "EUR"

# Help message
HELP_MESSAGE = """
Welcome to CurrenzBot! 💱

Here are the commands you can use:
/start - Start the bot and get a welcome message
/help - Show this help message
/rates - Get latest exchange rates for a base currency (default: EUR)
/convert - Convert one currency to another
/popular - Show popular currency exchange rates

Examples:
/rates USD - Get rates with USD as base
/convert 100 USD to EUR - Convert 100 USD to EUR

Use the button below to get the best exchange rates for your transactions!
"""

# Welcome message
WELCOME_MESSAGE = """
Hello! 👋 Welcome to CurrenzBot! 💱

I can help you check currency exchange rates with beautiful emojis!

Use /help to see available commands.
"""

# Default popular currencies to display
POPULAR_CURRENCIES = ["USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CNY", "INR"]
