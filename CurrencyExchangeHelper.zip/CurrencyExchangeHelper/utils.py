import re
from config import CURRENCY_EMOJIS, POPULAR_CURRENCIES

def format_currency_name(currency_code):
    """
    Format a currency code with its emoji if available
    
    Args:
        currency_code (str): The currency code (e.g., USD, EUR)
        
    Returns:
        str: Formatted currency name with emoji
    """
    emoji = CURRENCY_EMOJIS.get(currency_code, "🌐")
    return f"{emoji} {currency_code}"

def format_exchange_rate(base_currency, target_currency, rate):
    """
    Format an exchange rate with currencies and emojis
    
    Args:
        base_currency (str): The base currency code
        target_currency (str): The target currency code
        rate (float): The exchange rate value
        
    Returns:
        str: Formatted exchange rate string
    """
    base_formatted = format_currency_name(base_currency)
    target_formatted = format_currency_name(target_currency)
    
    return f"1 {base_formatted} = {rate:.4f} {target_formatted}"

def parse_convert_command(text):
    """
    Parse the conversion command text
    Expected format: "/convert 100 USD to EUR" or variations
    
    Args:
        text (str): The command text to parse
        
    Returns:
        tuple: (amount, from_currency, to_currency) or None if parsing failed
    """
    # Remove the command itself
    text = text.replace("/convert", "").strip()
    
    # Try different regex patterns to accommodate various input formats
    patterns = [
        r"(\d+(?:\.\d+)?)\s+(\w{3})\s+(?:to)?\s+(\w{3})",  # 100 USD to EUR or 100 USD EUR
        r"(\d+(?:\.\d+)?)\s+(\w{3})[\s/]+(\w{3})",         # 100 USD/EUR or 100 USD EUR
    ]
    
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            amount_str, from_currency, to_currency = match.groups()
            try:
                amount = float(amount_str)
                return amount, from_currency.upper(), to_currency.upper()
            except ValueError:
                return None
    
    return None

def format_popular_rates(rates_data):
    """
    Format popular currency rates into a readable message with emojis
    
    Args:
        rates_data (dict): Exchange rates data
        
    Returns:
        str: Formatted message with popular exchange rates
    """
    if not rates_data.get("success", False):
        return f"❌ Error: {rates_data.get('error', 'Unknown error')}"
    
    base = rates_data.get("base", "EUR")
    date = rates_data.get("date", "N/A")
    rates = rates_data.get("rates", {})
    
    message = [f"💱 Popular Exchange Rates (Base: {format_currency_name(base)})", 
               f"📅 Date: {date}", ""]
    
    for currency in POPULAR_CURRENCIES:
        if currency != base and currency in rates:
            message.append(format_exchange_rate(base, currency, rates[currency]))
    
    message.append("\n💡 Use /convert to convert between currencies")
    return "\n".join(message)

def format_all_rates(rates_data):
    """
    Format all currency rates into a readable message with emojis
    
    Args:
        rates_data (dict): Exchange rates data
        
    Returns:
        str: Formatted message with all exchange rates
    """
    if not rates_data.get("success", False):
        return f"❌ Error: {rates_data.get('error', 'Unknown error')}"
    
    base = rates_data.get("base", "EUR")
    date = rates_data.get("date", "N/A")
    rates = rates_data.get("rates", {})
    
    message = [f"💱 Exchange Rates (Base: {format_currency_name(base)})", 
               f"📅 Date: {date}", ""]
    
    # Sort currencies alphabetically
    sorted_currencies = sorted(rates.keys())
    
    for currency in sorted_currencies:
        if currency != base:
            message.append(format_exchange_rate(base, currency, rates[currency]))
    
    message.append("\n💡 Use /convert to convert between currencies")
    return "\n".join(message)

def format_conversion_result(conversion_data):
    """
    Format currency conversion result into a readable message with emojis
    
    Args:
        conversion_data (dict): Conversion result data
        
    Returns:
        str: Formatted message with conversion result
    """
    if not conversion_data.get("success", False):
        return f"❌ Error: {conversion_data.get('error', 'Unknown error')}"
    
    amount = conversion_data.get("amount", 0)
    from_currency = conversion_data.get("from", "")
    to_currency = conversion_data.get("to", "")
    result = conversion_data.get("result", 0)
    date = conversion_data.get("date", "N/A")
    
    from_formatted = format_currency_name(from_currency)
    to_formatted = format_currency_name(to_currency)
    
    message = [
        "💱 Currency Conversion Result",
        f"📅 Date: {date}",
        "",
        f"{amount:.2f} {from_formatted} = {result:.2f} {to_formatted}",
        "",
        "Want to convert more? Use the /convert command!"
    ]
    
    return "\n".join(message)
