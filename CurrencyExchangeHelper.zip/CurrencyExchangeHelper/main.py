import logging
import os
from flask import Flask, render_template, request, jsonify
from currency_api import get_exchange_rates, convert_currency
from config import DEFAULT_BASE_CURRENCY, POPULAR_CURRENCIES
from utils import format_currency_name

# Set up logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html', bot_username='CurrenzBot')

@app.route('/api/rates', methods=['GET'])
def rates():
    base_currency = request.args.get('base', DEFAULT_BASE_CURRENCY)
    response = get_exchange_rates(base_currency)
    return jsonify(response)

@app.route('/api/convert', methods=['GET'])
def convert():
    amount = request.args.get('amount', type=float)
    from_currency = request.args.get('from', '')
    to_currency = request.args.get('to', '')
    
    if not all([amount, from_currency, to_currency]):
        return jsonify({"success": False, "error": "Missing parameters"})
    
    response = convert_currency(amount, from_currency.upper(), to_currency.upper())
    return jsonify(response)

@app.route('/api/popular', methods=['GET'])
def popular():
    base_currency = request.args.get('base', DEFAULT_BASE_CURRENCY)
    response = get_exchange_rates(base_currency)
    
    if not response.get("success", False):
        return jsonify(response)
    
    # Filter rates to only include popular currencies
    rates = response.get("rates", {})
    popular_rates = {curr: rates.get(curr) for curr in POPULAR_CURRENCIES if curr in rates}
    
    # Replace with filtered rates
    response["rates"] = popular_rates
    return jsonify(response)

# Main entry point for running the bot separately
if __name__ == "__main__":
    from bot import start_bot
    start_bot()
