import logging
import re
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import (
    Updater, CommandHandler, CallbackContext, 
    MessageHandler, Filters
)

from config import (
    BOT_TOKEN, DEFAULT_BASE_CURRENCY, WELCOME_MESSAGE, 
    HELP_MESSAGE, CTA_TEXT, CTA_URL
)
from currency_api import get_exchange_rates, convert_currency
from utils import (
    format_popular_rates, format_all_rates, 
    format_conversion_result, parse_convert_command
)

# Set up logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", 
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Create the call-to-action button
def get_cta_button():
    """Returns the call-to-action button for Wise conversion"""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(text=CTA_TEXT, url=CTA_URL)]
    ])

def start_command(update: Update, context: CallbackContext):
    """Handle the /start command"""
    update.message.reply_text(
        WELCOME_MESSAGE,
        reply_markup=get_cta_button()
    )

def help_command(update: Update, context: CallbackContext):
    """Handle the /help command"""
    update.message.reply_text(
        HELP_MESSAGE,
        reply_markup=get_cta_button()
    )

def rates_command(update: Update, context: CallbackContext):
    """
    Handle the /rates command
    Format: /rates [currency_code]
    """
    # Get base currency from command arguments or use default
    base_currency = DEFAULT_BASE_CURRENCY
    if context.args and len(context.args[0]) == 3:
        base_currency = context.args[0].upper()
    
    # Inform user we're fetching rates
    update.message.reply_text(f"📊 Fetching latest rates for {base_currency}...")
    
    # Get exchange rates
    rates_data = get_exchange_rates(base_currency)
    
    # Format and send the response
    response = format_all_rates(rates_data)
    update.message.reply_text(
        response,
        reply_markup=get_cta_button()
    )

def convert_command(update: Update, context: CallbackContext):
    """
    Handle the /convert command
    Format: /convert 100 USD to EUR
    """
    text = update.message.text
    
    # Check if the command has any arguments
    if len(text.strip()) <= 9:  # "/convert " is 9 chars
        update.message.reply_text(
            "⚠️ Please specify the conversion details.\n"
            "Example: /convert 100 USD to EUR",
            reply_markup=get_cta_button()
        )
        return
    
    # Parse the conversion parameters
    parsed_data = parse_convert_command(text)
    
    if not parsed_data:
        update.message.reply_text(
            "❌ Invalid format. Please use:\n"
            "/convert 100 USD to EUR",
            reply_markup=get_cta_button()
        )
        return
    
    amount, from_currency, to_currency = parsed_data
    
    # Inform user we're processing the conversion
    update.message.reply_text(
        f"💱 Converting {amount} {from_currency} to {to_currency}..."
    )
    
    # Perform the conversion
    conversion_data = convert_currency(amount, from_currency, to_currency)
    
    # Format and send the response
    response = format_conversion_result(conversion_data)
    update.message.reply_text(
        response,
        reply_markup=get_cta_button()
    )

def popular_command(update: Update, context: CallbackContext):
    """
    Handle the /popular command
    Shows exchange rates for popular currencies
    """
    # Get base currency from command arguments or use default
    base_currency = DEFAULT_BASE_CURRENCY
    if context.args and len(context.args[0]) == 3:
        base_currency = context.args[0].upper()
    
    # Inform user we're fetching rates
    update.message.reply_text(f"📊 Fetching popular rates for {base_currency}...")
    
    # Get exchange rates
    rates_data = get_exchange_rates(base_currency)
    
    # Format and send the response
    response = format_popular_rates(rates_data)
    update.message.reply_text(
        response,
        reply_markup=get_cta_button()
    )

def unknown_command(update: Update, context: CallbackContext):
    """Handle unknown commands"""
    update.message.reply_text(
        "❓ Sorry, I don't understand that command.\n"
        "Use /help to see the available commands.",
        reply_markup=get_cta_button()
    )

def handle_message(update: Update, context: CallbackContext):
    """Handle regular messages (not commands)"""
    # Check if the message looks like a currency conversion request
    text = update.message.text.strip().upper()
    
    # Simple pattern matching for currency conversion phrases
    if any(phrase in text for phrase in ["CONVERT", "EXCHANGE", "FROM", "TO"]):
        # Try to extract conversion parameters
        for pattern in [
            r"(?:CONVERT|EXCHANGE)?\s*(\d+(?:\.\d+)?)\s+(\w{3})\s+(?:TO|INTO)\s+(\w{3})",
            r"(\d+(?:\.\d+)?)\s+(\w{3})\s+(?:TO|INTO)\s+(\w{3})"
        ]:
            match = re.search(pattern, text)
            if match:
                amount, from_currency, to_currency = match.groups()
                try:
                    amount = float(amount)
                    # Perform the conversion
                    update.message.reply_text(
                        f"💱 Converting {amount} {from_currency} to {to_currency}..."
                    )
                    conversion_data = convert_currency(amount, from_currency, to_currency)
                    response = format_conversion_result(conversion_data)
                    update.message.reply_text(
                        response,
                        reply_markup=get_cta_button()
                    )
                    return
                except ValueError:
                    pass
    
    # Default response for other messages
    update.message.reply_text(
        "👋 Hello! I'm CurrenzBot, your currency exchange assistant.\n"
        "Use /help to see what I can do for you!",
        reply_markup=get_cta_button()
    )

def start_bot():
    """Initialize and start the bot"""
    # Create updater instance
    updater = Updater(BOT_TOKEN)
    dispatcher = updater.dispatcher
    
    # Add command handlers
    dispatcher.add_handler(CommandHandler("start", start_command))
    dispatcher.add_handler(CommandHandler("help", help_command))
    dispatcher.add_handler(CommandHandler("rates", rates_command))
    dispatcher.add_handler(CommandHandler("convert", convert_command))
    dispatcher.add_handler(CommandHandler("popular", popular_command))
    
    # Handle regular messages
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))
    
    # Handle unknown commands
    dispatcher.add_handler(MessageHandler(Filters.command, unknown_command))
    
    # Start the bot
    logger.info("Starting bot...")
    updater.start_polling()
    updater.idle()
    
    return updater
