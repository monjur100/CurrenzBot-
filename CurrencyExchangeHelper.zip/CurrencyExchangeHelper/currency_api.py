import requests
import logging
from config import EXCHANGE_RATE_API_URL, DEFAULT_BASE_CURRENCY

logger = logging.getLogger(__name__)

def get_exchange_rates(base_currency=DEFAULT_BASE_CURRENCY):
    """
    Fetch current exchange rates using the provided API
    
    Args:
        base_currency (str): The base currency code (default: EUR)
        
    Returns:
        dict: Exchange rate data or error message
    """
    try:
        url = f"{EXCHANGE_RATE_API_URL}{base_currency}"
        
        response = requests.get(url)
        data = response.json()
        
        if response.status_code != 200 or data.get("result") == "error":
            error_message = data.get("error-type", "Unknown error")
            logger.error(f"API Error: {error_message}")
            return {
                "success": False,
                "error": f"Failed to fetch exchange rates: {error_message}. Please try again later."
            }
            
        return {
            "success": True,
            "base": data.get("base_code", base_currency),
            "date": data.get("time_last_update_utc", "N/A"),
            "rates": data.get("rates", {})
        }
        
    except Exception as e:
        logger.error(f"Error fetching exchange rates: {str(e)}")
        return {
            "success": False,
            "error": "An unexpected error occurred. Please try again later."
        }

def convert_currency(amount, from_currency, to_currency):
    """
    Convert an amount from one currency to another
    
    Args:
        amount (float): The amount to convert
        from_currency (str): The source currency code
        to_currency (str): The target currency code
        
    Returns:
        dict: Conversion result or error message
    """
    try:
        # Get rates using the from_currency as base
        response = get_exchange_rates(from_currency)
        
        if not response["success"]:
            return response
        
        rates = response["rates"]
        
        # Check if target currency exists in rates
        if to_currency not in rates:
            return {
                "success": False,
                "error": f"Currency '{to_currency}' not found"
            }
        
        # Direct conversion
        converted_amount = amount * rates[to_currency]
        
        return {
            "success": True,
            "amount": amount,
            "from": from_currency,
            "to": to_currency,
            "result": converted_amount,
            "date": response["date"]
        }
        
    except Exception as e:
        logger.error(f"Error converting currency: {str(e)}")
        return {
            "success": False,
            "error": "An unexpected error occurred during conversion. Please try again later."
        }
